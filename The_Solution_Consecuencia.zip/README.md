# Consecuencia — Project Intelligence & Decision Traceability

**Every failure has a chain. Find it.**

Consecuencia is an organizational intelligence platform concept that helps companies understand the complete chain of events behind their projects by connecting decisions, workflows, actions, and dependencies.

## Quick Start (Local Development)

```bash
npm install
npm run dev
```

## Push to GitHub (`AKSCI-Morningstar/The_Solution`)

```bash
git init
git add .
git commit -m "feat: build Consecuencia enterprise SaaS landing page and interactive Project Alpha demo"
git branch -M main
git remote add origin https://github.com/AKSCI-Morningstar/The_Solution.git
git push -u origin main --force
```
